plugins { id("com.android.application") }

android {
    namespace = "nl.shipsim.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "nl.shipsim.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 13
        versionName = "0.7"
    }
    // Vaste sleutel, zodat een nieuwe APK over de vorige heen installeert (spelstand blijft).
    signingConfigs {
        getByName("debug") {
            storeFile = file("shipsim-debug.keystore")
            storePassword = "android"; keyAlias = "androiddebugkey"; keyPassword = "android"
        }
    }
    buildTypes {
        release { isMinifyEnabled = false }
        debug { applicationIdSuffix = "" }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}

dependencies {
    // lijnt kotlin-stdlib-jdk7/jdk8 uit met kotlin-stdlib (anders "Duplicate class kotlin...")
    implementation(platform("org.jetbrains.kotlin:kotlin-bom:1.8.22"))
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
