plugins { id("com.android.application") }

android {
    namespace = "nl.shipsim.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "nl.shipsim.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "0.3"
    }
    buildTypes {
        release { isMinifyEnabled = false }
        debug { applicationIdSuffix = "" }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}

dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
