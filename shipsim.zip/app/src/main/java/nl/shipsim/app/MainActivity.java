package nl.shipsim.app;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

/** Ship Sim: de webversie in een WebView. Spelstand blijft bewaard in localStorage van de app. */
public class MainActivity extends AppCompatActivity {
    private WebView web;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); // scherm aan tijdens spelen
        web.setBackgroundColor(0xFF0B1B2B);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);      // localStorage voor de spelstand
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setTextZoom(100);
        s.setSupportZoom(false);

        // Laad het spel rechtstreeks uit de app-bestanden (werkt zonder netwerk; localStorage blijft bewaard).
        web.setWebViewClient(new WebViewClient());

        // Terugknop: sluit een open venster in het spel, anders app naar achtergrond (spel slaat zelf op).
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                web.evaluateJavascript(
                    "(function(){ if (typeof openScreen !== 'undefined' && openScreen && openScreen !== 'event' && openScreen !== 'new') { closeModal(); return 'closed'; } if (typeof W !== 'undefined' && W) { saveGame(); } return 'home'; })()",
                    value -> { if (value != null && value.contains("home")) moveTaskToBack(true); });
            }
        });

        if (savedInstanceState == null) web.loadUrl("file:///android_asset/index.html");
        else web.restoreState(savedInstanceState);
    }

    @Override protected void onPause() { super.onPause(); web.evaluateJavascript("if (typeof W !== 'undefined' && W) { W.speed = 0; saveGame(); }", null); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
    @Override protected void onSaveInstanceState(Bundle outState) { super.onSaveInstanceState(outState); web.saveState(outState); }
    @Override protected void onDestroy() { web.destroy(); super.onDestroy(); }
}
