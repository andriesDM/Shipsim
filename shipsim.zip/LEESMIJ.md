# Shipping World – Android-app en webversie

Eén GitHub-repository (andriesDM/Shipsim) bouwt alles automatisch:
- `shipsim.apk` voor Android (eigen gebruik, niet via de Play Store);
- de webversie op https://andriesdm.github.io/Shipsim/ (iPad: Safari → Deel → Zet op beginscherm; desktop: "App installeren" in Chrome/Edge). Werkt na de eerste keer ook offline.

## Nieuwe versie plaatsen
1. Upload de nieuwe `shipsim.zip` op GitHub (Code → + → Upload files → Commit changes).
2. Wacht in **Actions** tot de run groen is (ca. 5 minuten).
3. Android: download https://andriesdm.github.io/Shipsim/shipsim.apk en installeer over de oude versie heen (spelstand blijft; de APK is met een vaste sleutel getekend).
   Web: gewoon openen met internet aan; de nieuwe versie wordt vanzelf opgehaald.

## Inhoud
- `app/src/main/assets/index.html`: het hele spel (één bestand, gegenereerd door build.py).
- `app/src/main/java/nl/shipsim/app/MainActivity.java`: WebView; terugknop sluit vensters in het spel, scherm blijft aan, automatisch opslaan bij naar achtergrond gaan.
- `app/shipsim-debug.keystore`: vaste handtekening voor updates.
- `web/`: dezelfde index.html met manifest, iconen en service worker (PWA).
- `.github/workflows/build.yml` (staat los in de repository): pakt de zip uit, bouwt de APK, zet web/ + APK op GitHub Pages.

De spelstand staat per toestel in localStorage (Android: in de app; web: in de browser). Kantoor → Opslaan kan een spelstand als tekst kopiëren naar een ander toestel.
